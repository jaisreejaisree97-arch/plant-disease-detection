from flask import Flask, render_template, request
import tensorflow as tf
import numpy as np
from PIL import Image
import json

app = Flask(__name__)

model = tf.keras.models.load_model("model.h5")

with open("class_indices.json", "r") as f:
    class_indices = json.load(f)

labels = {v:k for k,v in class_indices.items()}

cures = {
    "Tomato___Early_blight": "Use fungicide and remove affected leaves.",
    "Tomato___Late_blight": "Avoid overhead watering and apply copper fungicide."
}

@app.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        file = request.files['image']
        img = Image.open(file).resize((224,224))
        img = np.array(img)/255.0
        img = img.reshape(1,224,224,3)

        pred = model.predict(img)
        result_index = np.argmax(pred)
        disease = labels[result_index]
        cure = cures.get(disease, "No cure info available")

        return render_template("result.html", disease=disease, cure=cure)

    return render_template("index.html")

@app.route('/accuracy')
def accuracy():
    return render_template("accuracy.html")

if __name__ == '__main__':
    app.run(debug=True)
